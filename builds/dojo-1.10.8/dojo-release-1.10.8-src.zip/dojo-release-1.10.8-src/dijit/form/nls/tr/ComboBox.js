define(
({
		previousMessage: "Önceki seçenekler",
		nextMessage: "Diğer seçenekler"
})
);
