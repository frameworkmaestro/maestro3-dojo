define(
({
		previousMessage: "Opcions anteriors",
		nextMessage: "Més opcions"
})
);
